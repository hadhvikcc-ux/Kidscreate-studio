package com.kidscreate.studio.data

import android.content.Context
import androidx.compose.ui.geometry.Offset
import com.kidscreate.studio.draw.FlipbookState
import com.kidscreate.studio.draw.Frame
import com.kidscreate.studio.draw.Stroke
import kotlinx.serialization.Serializable
import java.io.File

@Serializable
data class SavedStroke(val color: String, val width: Float, val eraser: Boolean, val xs: List<Float>, val ys: List<Float>)

@Serializable
data class SavedFrame(val hold: Int, val strokes: List<SavedStroke>)

@Serializable
data class SavedCartoon(val title: String, val fps: Int, val pingPong: Boolean, val savedAt: Long, val frames: List<SavedFrame>)

/** Cartoons are saved as small JSON files in the app's private folder. Nothing leaves the device. */
object CartoonStore {
    private fun dir(context: Context) = File(context.filesDir, "cartoons").apply { mkdirs() }

    fun save(context: Context, title: String, fb: FlipbookState): File {
        val cartoon = SavedCartoon(
            title = title.ifBlank { "My Cartoon" },
            fps = fb.fps,
            pingPong = fb.pingPong,
            savedAt = System.currentTimeMillis(),
            frames = fb.frames.map { f ->
                SavedFrame(f.hold, f.strokes.map { s ->
                    SavedStroke(s.colorName, s.width, s.eraser, s.points.map { it.x }, s.points.map { it.y })
                })
            },
        )
        val file = File(dir(context), "cartoon_${cartoon.savedAt}.json")
        file.writeText(LessonRepository.json.encodeToString(SavedCartoon.serializer(), cartoon))
        return file
    }

    fun list(context: Context): List<Pair<File, SavedCartoon>> =
        dir(context).listFiles().orEmpty()
            .filter { it.extension == "json" }
            .mapNotNull { f ->
                runCatching { f to LessonRepository.json.decodeFromString(SavedCartoon.serializer(), f.readText()) }.getOrNull()
            }
            .sortedByDescending { it.second.savedAt }

    fun loadInto(cartoon: SavedCartoon, fb: FlipbookState) {
        fb.resetAll()
        fb.frames.clear()
        cartoon.frames.forEach { sf ->
            val f = Frame()
            f.hold = sf.hold
            sf.strokes.forEach { ss ->
                val s = Stroke(ss.color, ss.width, ss.eraser)
                s.points.addAll(ss.xs.indices.map { Offset(ss.xs[it], ss.ys[it]) })
                f.strokes.add(s)
            }
            fb.frames.add(f)
        }
        if (fb.frames.isEmpty()) fb.frames.add(Frame())
        fb.fps = cartoon.fps
        fb.pingPong = cartoon.pingPong
        fb.current = 0
    }

    fun delete(file: File) {
        file.delete()
    }
}
