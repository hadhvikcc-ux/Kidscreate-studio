package com.kidscreate.studio.lesson

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

/** Reads step cards aloud with the phone's built-in voice (works offline once a voice is installed). */
class Speaker(context: Context) : TextToSpeech.OnInitListener {
    private val tts = TextToSpeech(context.applicationContext, this)
    private var ready = false
    private var pending: String? = null

    override fun onInit(status: Int) {
        ready = status == TextToSpeech.SUCCESS
        if (ready) {
            val indian = tts.setLanguage(Locale.forLanguageTag("en-IN"))
            if (indian < TextToSpeech.LANG_AVAILABLE) tts.setLanguage(Locale.ENGLISH)
            tts.setSpeechRate(0.92f)
            tts.setPitch(1.1f)
            pending?.let { say(it) }
            pending = null
        }
    }

    fun say(text: String) {
        if (!ready) {
            pending = text; return
        }
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "step")
    }

    fun stop() {
        if (ready) tts.stop()
    }

    fun shutdown() {
        tts.shutdown()
    }
}
