package com.kidscreate.studio.draw

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import kotlin.math.cos
import kotlin.math.sin

/** Canvas is 640 x 420 "paper units"; points are stored as 0..1 of width and height. */
const val CANVAS_ASPECT = 640f / 420f

enum class Tool { Pen, Eraser }

/** Named colours, so lessons can say "pick green" and check for it. */
val PALETTE: List<Pair<String, Color>> = listOf(
    "ink" to Color(0xFF18203D),
    "red" to Color(0xFFF2503F),
    "orange" to Color(0xFFFF8A1F),
    "yellow" to Color(0xFFF5B700),
    "green" to Color(0xFF1A9354),
    "blue" to Color(0xFF2B7BE4),
    "purple" to Color(0xFF7151EE),
)

fun colorOf(name: String): Color = PALETTE.firstOrNull { it.first == name }?.second ?: PALETTE[0].second

class Stroke(
    val colorName: String,
    val width: Float,
    val eraser: Boolean,
    val tag: String? = null,
) {
    val points = mutableStateListOf<Offset>()
    fun copy(): Stroke = Stroke(colorName, width, eraser, tag).also { it.points.addAll(points) }
}

class Frame {
    val strokes = mutableStateListOf<Stroke>()
    /** How many ticks this frame stays on screen when playing. */
    var hold by mutableIntStateOf(1)
    /** Pen strokes drawn on this frame since it was made (copies start at 0). */
    var strokesAdded by mutableIntStateOf(0)
    var eraserUsed by mutableStateOf(false)
}

data class PlayInfo(val fps: Int, val pingPong: Boolean)

class FlipbookState {
    val frames = mutableStateListOf(Frame())
    var current by mutableIntStateOf(0)
    var tool by mutableStateOf(Tool.Pen)
    var colorName by mutableStateOf("ink")
    var onion by mutableStateOf(true)
    var fps by mutableIntStateOf(7)
    var pingPong by mutableStateOf(true)
    var playing by mutableStateOf(false)
    /** Frame shown while playing. */
    var showIndex by mutableIntStateOf(0)
    /** Set each time Play starts; lessons reset it to null at the start of a step. */
    var lastPlay by mutableStateOf<PlayInfo?>(null)
    var saved by mutableStateOf(false)
    var acknowledged by mutableStateOf(false)

    private var active: Stroke? = null

    val currentFrame: Frame get() = frames[current]

    fun beginStroke(p: Offset) {
        stop()
        val s = Stroke(colorName, if (tool == Tool.Eraser) 0.045f else 0.014f, tool == Tool.Eraser)
        s.points.add(p)
        currentFrame.strokes.add(s)
        active = s
    }

    fun addPoint(p: Offset) {
        active?.points?.add(p)
    }

    fun endStroke() {
        val s = active ?: return
        if (s.eraser) currentFrame.eraserUsed = true else currentFrame.strokesAdded++
        active = null
    }

    fun select(i: Int) {
        stop()
        current = i.coerceIn(0, frames.lastIndex)
    }

    fun addFrame() {
        stop()
        frames.add(current + 1, Frame())
        current++
    }

    fun copyFrame() {
        stop()
        val f = Frame()
        currentFrame.strokes.forEach { f.strokes.add(it.copy()) }
        frames.add(current + 1, f)
        current++
    }

    fun clearFrame() {
        stop()
        currentFrame.strokes.clear()
    }

    fun deleteFrame() {
        stop()
        if (frames.size == 1) {
            frames[0].strokes.clear(); return
        }
        frames.removeAt(current)
        current = current.coerceAtMost(frames.lastIndex)
    }

    fun holdMore() {
        currentFrame.hold = (currentFrame.hold + 1).coerceAtMost(8)
    }

    fun holdLess() {
        currentFrame.hold = (currentFrame.hold - 1).coerceAtLeast(1)
    }

    /** Frame order for one loop, each frame repeated by its hold count. */
    fun playSequence(): List<Int> {
        val order = frames.indices.toMutableList()
        if (pingPong && frames.size > 2) order += (frames.size - 2 downTo 1)
        return order.flatMap { i -> List(frames[i].hold) { i } }
    }

    fun play(): Boolean {
        if (frames.size < 2) return false
        playing = true
        lastPlay = PlayInfo(fps, pingPong)
        return true
    }

    fun stop() {
        playing = false
    }

    fun togglePlay(): Boolean = if (playing) { stop(); true } else play()

    // ---- helpers used by "Do it for me" and samples ----

    fun ensureFrame(index: Int) {
        while (frames.size <= index) frames.add(Frame())
        current = index
    }

    fun addPenStroke(points: List<Offset>, color: String = "red", tag: String? = null, width: Float = 0.016f) {
        val s = Stroke(color, width, false, tag)
        s.points.addAll(points)
        currentFrame.strokes.add(s)
        currentFrame.strokesAdded++
    }

    /** A filled-looking ball: an outline plus a few rings inside. rx is in width units. */
    fun addEllipse(cx: Float, cy: Float, rx: Float, ry: Float = rx * CANVAS_ASPECT, color: String = "red", tag: String? = null) {
        var r = 1f
        while (r > 0.12f) {
            val pts = (0..42).map { k ->
                val a = (k / 42f) * 2f * Math.PI.toFloat()
                Offset(cx + cos(a) * rx * r, cy + sin(a) * ry * r)
            }
            addPenStroke(pts, color, tag)
            r -= 0.22f
        }
    }

    fun addLine(x1: Float, y1: Float, x2: Float, y2: Float, color: String = "ink", tag: String? = null) {
        addPenStroke((0..10).map { k -> val t = k / 10f; Offset(x1 + (x2 - x1) * t, y1 + (y2 - y1) * t) }, color, tag)
    }

    fun removeTagged(tag: String) {
        currentFrame.strokes.removeAll { it.tag == tag }
        currentFrame.eraserUsed = true
    }

    fun resetAll() {
        stop()
        frames.clear()
        frames.add(Frame())
        current = 0
        lastPlay = null
        saved = false
    }
}
