package com.kidscreate.studio.lesson

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kidscreate.studio.data.CartoonStore
import com.kidscreate.studio.data.Lesson
import com.kidscreate.studio.data.Progress
import com.kidscreate.studio.draw.FlipbookState
import com.kidscreate.studio.draw.FlipbookStudio
import com.kidscreate.studio.ui.Kc
import com.kidscreate.studio.ui.ScreenHeader
import com.kidscreate.studio.ui.glow

/**
 * The lesson player: a step card on top, the real studio underneath.
 * Watch the intro, do each step (the app checks it), play it back, then take the challenge.
 */
@Composable
fun LessonScreen(lesson: Lesson, progress: Progress, onBack: () -> Unit, onDone: () -> Unit) {
    val context = LocalContext.current
    val speaker = remember { Speaker(context) }
    DisposableEffect(Unit) { onDispose { speaker.shutdown() } }

    val fb = remember(lesson.id) { FlipbookState() }
    var stepIndex by remember(lesson.id) { mutableIntStateOf(0) }
    var helpLevel by remember(stepIndex) { mutableIntStateOf(0) }
    var forced by remember(stepIndex) { mutableStateOf(false) }
    var finished by remember(lesson.id) { mutableStateOf(false) }
    val step = lesson.steps[stepIndex]
    val isLast = stepIndex == lesson.steps.lastIndex
    val pro = progress.grade == "9-10"

    // Each step starts fresh: playing or saving in an earlier step does not count.
    LaunchedEffect(stepIndex) {
        fb.lastPlay = null
        fb.acknowledged = false
        if (progress.readAloud) speaker.say(step.say)
    }

    val passed by remember(stepIndex) { derivedStateOf { forced || LessonChecker.passes(step.check, fb) } }

    Column(
        Modifier.verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        ScreenHeader(lesson.title, onBack)

        // Step card
        Column(
            Modifier
                .fillMaxWidth()
                .background(Kc.Surface, RoundedCornerShape(22.dp))
                .border(2.dp, Kc.Draw, RoundedCornerShape(22.dp))
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "Step ${stepIndex + 1}", color = androidx.compose.ui.graphics.Color.White, fontWeight = FontWeight.ExtraBold,
                    modifier = Modifier.background(Kc.Draw, RoundedCornerShape(10.dp)).padding(horizontal = 10.dp, vertical = 2.dp),
                )
                Text("  of ${lesson.steps.size}", color = Kc.Muted, fontSize = 13.sp)
                Spacer(Modifier.weight(1f))
                lesson.steps.indices.forEach { k ->
                    Box(
                        Modifier.padding(start = 5.dp).size(10.dp).background(
                            when {
                                k < stepIndex -> Kc.Good
                                k == stepIndex -> Kc.Draw
                                else -> Kc.Line
                            }, CircleShape,
                        ),
                    )
                }
            }
            Row(verticalAlignment = Alignment.Top) {
                Text(step.say, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
                FilledTonalIconButton(onClick = { speaker.say(step.say) }) {
                    Icon(Icons.AutoMirrored.Filled.VolumeUp, contentDescription = "Read aloud")
                }
            }
            if (pro && step.pro != null) {
                Text(
                    step.pro, fontSize = 13.sp, color = Kc.Muted,
                    modifier = Modifier.background(Kc.Sunk, RoundedCornerShape(8.dp)).padding(8.dp),
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (passed) {
                    Icon(Icons.Filled.CheckCircle, null, tint = Kc.Good)
                    Text(if (isLast) " You did it!" else " Great job!", color = Kc.Good, fontWeight = FontWeight.SemiBold)
                } else {
                    Text("Your turn! Try it below.", color = Kc.Muted, fontSize = 13.sp)
                }
                Spacer(Modifier.weight(1f))
                if (!passed) {
                    OutlinedButton(onClick = {
                        helpLevel++
                        if (helpLevel == 1) {
                            speaker.say(step.say)
                        } else {
                            val did = AutoActions.run(step.auto, fb)
                            if (!did || step.check.str("type") == "acknowledged") fb.acknowledged = true
                            if (!did) forced = true
                        }
                    }) {
                        Icon(Icons.Filled.Lightbulb, null)
                        Text(if (helpLevel == 0) " Help me" else " Do it for me")
                    }
                }
                if (step.check.str("type") == "acknowledged" && !passed) {
                    Spacer(Modifier.width(8.dp))
                    Button(onClick = { fb.acknowledged = true }) { Text("I've got an idea!") }
                }
                if (passed) {
                    Button(
                        onClick = {
                            if (isLast) {
                                fb.stop()
                                progress.complete(lesson)
                                finished = true
                            } else {
                                stepIndex++
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Kc.Ink),
                        modifier = Modifier.glow(true, 24),
                    ) { Text(if (isLast) "Finish" else "Next") }
                }
            }
        }

        FlipbookStudio(
            fb = fb,
            glow = if (passed) null else step.glow,
            ghost = if (helpLevel >= 1 && !passed) step.ghost else null,
            onSave = {
                CartoonStore.save(context, "${lesson.title} by ${progress.name}", fb)
                fb.saved = true
            },
        )

        if (lesson.challenge.isNotBlank()) {
            Column(
                Modifier.fillMaxWidth().background(Kc.Surface, RoundedCornerShape(18.dp)).padding(14.dp),
            ) {
                Text("CHALLENGE", style = MaterialTheme.typography.labelSmall, color = Kc.Muted)
                Text(lesson.challenge, fontWeight = FontWeight.Medium)
            }
        }
    }

    if (finished) {
        AlertDialog(
            onDismissRequest = onDone,
            icon = { Icon(Icons.Filled.EmojiEvents, null, tint = Kc.Draw, modifier = Modifier.size(56.dp)) },
            title = { Text("Lesson finished!") },
            text = {
                Text(
                    "You made \"${lesson.title}\", ${progress.name}." +
                        (lesson.badge?.let { " You earned a new badge!" } ?: "") +
                        " The next lesson is now open.",
                )
            },
            confirmButton = { Button(onClick = onDone) { Text("Next lesson") } },
            dismissButton = { TextButton(onClick = { finished = false; fb.play() }) { Text("Watch it again") } },
        )
    }
}
