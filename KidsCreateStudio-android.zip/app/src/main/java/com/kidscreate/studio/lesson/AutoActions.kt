package com.kidscreate.studio.lesson

import androidx.compose.ui.geometry.Offset
import com.kidscreate.studio.draw.CANVAS_ASPECT
import com.kidscreate.studio.draw.FlipbookState
import kotlinx.serialization.json.JsonObject
import kotlin.math.cos
import kotlin.math.sin

/**
 * "Do it for me": performs a step for the child, from the step's "auto" JSON.
 * Returns false when there is nothing it can do; the lesson then just lets the child move on.
 */
object AutoActions {

    fun run(a: JsonObject?, fb: FlipbookState): Boolean {
        if (a == null) return false
        val frame = a.int("frame")
        fun go() { if (frame != null) fb.ensureFrame(frame) }
        when (a.str("op")) {
            "ellipse" -> {
                go()
                val rx = a.num("rx") ?: 0.06f
                fb.addEllipse(a.num("x") ?: 0.5f, a.num("y") ?: 0.5f, rx, a.num("ry") ?: rx * CANVAS_ASPECT, a.str("color") ?: "red")
            }
            "line" -> {
                go()
                fb.addLine(a.num("x1") ?: 0.5f, a.num("y1") ?: 0.9f, a.num("x2") ?: 0.5f, a.num("y2") ?: 0.5f, a.str("color") ?: "ink")
            }
            "addFrame" -> fb.addFrame()
            "copyFrame" -> {
                fb.copyFrame()
                when {
                    a.str("thenArm") != null -> { fb.removeTagged("arm"); arm(fb, a.str("thenArm")!!) }
                    a.str("thenErase") != null -> fb.removeTagged(a.str("thenErase")!!)
                }
            }
            "play" -> {
                a.bool("pingpong")?.let { fb.pingPong = it }
                fb.play()
            }
            "setFps" -> {
                fb.fps = a.int("fps") ?: fb.fps
                a.bool("pingpong")?.let { fb.pingPong = it }
                if (a.bool("thenPlay") == true) fb.play()
            }
            "hold" -> {
                go()
                repeat(a.int("times") ?: 2) { fb.holdMore() }
                fb.play()
            }
            "burst" -> {
                go()
                val cx = a.num("x") ?: 0.5f
                val cy = a.num("y") ?: 0.25f
                val colors = listOf("red", "yellow", "blue", "green", "purple", "orange")
                for (k in 0 until 12) {
                    val ang = k / 12f * 2f * Math.PI.toFloat()
                    fb.addLine(
                        cx + cos(ang) * 0.03f, cy + sin(ang) * 0.03f * CANVAS_ASPECT,
                        cx + cos(ang) * 0.13f, cy + sin(ang) * 0.13f * CANVAS_ASPECT,
                        colors[k % colors.size],
                    )
                }
            }
            "leaf" -> {
                go()
                fb.addEllipse(a.num("x") ?: 0.5f, a.num("y") ?: 0.5f, 0.05f, 0.04f, "orange")
            }
            "rollTo" -> {
                val y = a.num("y") ?: 0.82f
                val rx = a.num("rx") ?: 0.06f
                val endX = a.num("x") ?: 0.85f
                val startIndex = fb.frames.size
                val n = (4 - startIndex).coerceAtLeast(1)
                val lastX = LessonChecker.stats(fb, fb.frames.lastIndex)?.cx ?: 0.15f
                for (k in 1..n) {
                    fb.ensureFrame(fb.frames.size)
                    fb.addEllipse(lastX + (endX - lastX) * k / n, y, rx)
                }
            }
            "face" -> {
                go()
                face(fb, open = a.str("eyes") != "closed")
            }
            "eraseEyes" -> {
                go()
                fb.removeTagged("eye")
            }
            "closedEyes" -> {
                go()
                fb.addLine(0.43f, 0.38f, 0.47f, 0.38f, "ink", "eye")
                fb.addLine(0.53f, 0.38f, 0.57f, 0.38f, "ink", "eye")
            }
            "stick" -> {
                go()
                fb.addEllipse(0.5f, 0.22f, 0.035f, color = "ink")
                fb.addLine(0.5f, 0.32f, 0.5f, 0.6f)
                fb.addLine(0.5f, 0.6f, 0.44f, 0.86f)
                fb.addLine(0.5f, 0.6f, 0.56f, 0.86f)
                fb.addLine(0.5f, 0.4f, 0.44f, 0.56f)
                arm(fb, a.str("arm") ?: "down")
            }
            "arm" -> {
                go()
                arm(fb, a.str("pose") ?: "side")
            }
            "loadSample" -> {
                fb.resetAll()
                fb.addEllipse(0.5f, 0.2f, 0.066f)
                fb.addFrame(); fb.addEllipse(0.5f, 0.5f, 0.066f)
                fb.addFrame(); fb.addEllipse(0.5f, 0.84f, 0.09f, 0.07f)
            }
            else -> return false
        }
        return true
    }

    /** The waving arm, on the right side of a stick person. */
    private fun arm(fb: FlipbookState, pose: String) {
        when (pose) {
            "up" -> fb.addLine(0.5f, 0.4f, 0.58f, 0.16f, "ink", "arm")
            "side" -> fb.addLine(0.5f, 0.4f, 0.63f, 0.38f, "ink", "arm")
            else -> fb.addLine(0.5f, 0.4f, 0.56f, 0.56f, "ink", "arm")
        }
    }

    private fun face(fb: FlipbookState, open: Boolean) {
        val pts = (0..48).map { k ->
            val ang = k / 48f * 2f * Math.PI.toFloat()
            Offset(0.5f + cos(ang) * 0.17f, 0.45f + sin(ang) * 0.17f * CANVAS_ASPECT)
        }
        fb.addPenStroke(pts, "ink")
        if (open) {
            fb.addEllipse(0.45f, 0.38f, 0.018f, color = "ink", tag = "eye")
            fb.addEllipse(0.55f, 0.38f, 0.018f, color = "ink", tag = "eye")
        }
        val smile = (0..12).map { k ->
            val ang = (0.15f + 0.7f * k / 12f) * Math.PI.toFloat()
            Offset(0.5f + cos(ang) * 0.08f, 0.5f + sin(ang) * 0.06f * CANVAS_ASPECT)
        }
        fb.addPenStroke(smile, "ink")
    }
}
