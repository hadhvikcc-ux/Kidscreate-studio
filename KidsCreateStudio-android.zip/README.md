# KidsCreate Studio (Android)

This is the first version of KidsCreate Studio, an Android app for children in Grades 4–10. It covers Phase 1 of the roadmap: the guided Draw & Animate lessons, a free flipbook studio and Music Maker.

## What works in this version

- **Profile:** the child picks a nickname, a buddy and a grade. Nothing else about them is stored.
- **Learn:** 10 Draw & Animate lessons (`app/src/main/assets/lessons`). Each lesson unlocks after the one before it is finished. Grade 9–10 can open any lesson.
- **Lesson player:** each step card is read aloud with the phone's text-to-speech voice. The button the step needs glows on screen. The app checks the child's drawing to see if the step is done. "Help me" shows a dotted shape to draw inside, and "Do it for me" does the step for them.
- **Draw & Animate studio:**
  - pencil, eraser and seven colours
  - onion-skin, so the last page shows faintly
  - add, copy and delete pages, and hold a page for longer
  - a speed slider and a "bounce back" switch
  - save to My Movies
- **Music Maker:** an 8-step beat grid with kick, snare, hi-hat and clap, plus 8 melody keys (C D E G A / Sa Re Ga Pa Dha). The app makes all sounds itself, so it needs no audio files.
- **My Movies:** saved cartoons (stored as JSON files on the device). Tap one to open it, or delete it.
- **Parent area:** behind a times-table question. Shows progress and has the read-aloud setting.
- **3D Builder and Movie Editor:** placeholder screens for now. These studios come in Phase 2.

## Build the APK with GitHub Actions (from your phone)

1. Create a new GitHub repository, for example `kidscreate-studio`.
2. Upload everything in this folder, including the hidden `.github` folder and `gradlew`.
3. Each push starts the **Build APK** workflow. You can also start it by hand from the Actions tab with "Run workflow".
4. When it finishes, open the run and download **KidsCreateStudio-debug-apk**. Unzip it and install the APK on your phone.

Tools used: Gradle 8.11.1, Android Gradle Plugin 8.7.3, Kotlin 2.1.0, Jetpack Compose (BOM 2024.12.01), compileSdk/targetSdk 35 and minSdk 26 (Android 8.0).

## Project layout

```
app/src/main/
  assets/lessons/            lesson scripts (JSON) — add new lessons here
  java/com/kidscreate/studio/
    MainActivity.kt          app shell, bottom tabs, navigation
    data/                    Lesson model + loader, Progress (prefs), CartoonStore (saved cartoons)
    draw/                    FlipbookState (pages, strokes, playback) and FlipbookStudio (the UI)
    lesson/                  LessonScreen, LessonChecker (step checks), AutoActions ("Do it for me"), Speaker (TTS)
    music/                   Synth (built-in sounds) and MusicScreen
    ui/                      theme, colours, Home, Learn, My Movies, Parent, Profile screens
```

## Adding a lesson

Copy one of the JSON files and change it. Positions on the canvas run from 0 to 1, across and down. Each step has:

- `say`: the instruction, which is read aloud
- `check`: the test that decides when the step is done. The types are:
  - `drawingOn`, `frameCount`
  - `below`, `above`, `leftOf`, `rightOf`
  - `taller`, `tallerThanWide`, `widerThanTall`
  - `colorUsed`, `colorsUsed`, `strokes`, `strokesAdded`, `toolUsed`, `holdAtLeast`
  - `played`, `fpsAtMost`, `playedAtFpsAtMost`, `playedAtFpsAtLeast`
  - `acknowledged`, `saved`
  - `all` (combines several checks)
- `glow` (optional): the control to highlight, such as `tool.pen`, `action.addFrame`, `action.play`, `color.green` or `canvas`
- `ghost` (optional): the dotted shape that "Help me" shows
- `pro` (optional): an extra tip shown only to Grade 9–10
- `auto` (optional): what "Do it for me" does

If a check type is unknown, the step passes. That way an older app never leaves a child stuck on a newer lesson.

## Before the Play Store

- Make a release signing key, and build an AAB with `./gradlew bundleRelease`.
- Fill in Google Play's Families policy forms and the Data safety form. The app collects no personal data and has no ads.
- Write a privacy policy page.
