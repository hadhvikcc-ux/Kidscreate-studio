package com.kidscreate.studio.ui

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

object Kc {
    val Bg = Color(0xFFE6EEFF)
    val Surface = Color(0xFFFFFFFF)
    val Sunk = Color(0xFFF1F5FF)
    val Ink = Color(0xFF18203D)
    val Muted = Color(0xFF55608A)
    val Line = Color(0xFFD3DCF3)
    val Draw = Color(0xFFF2503F)
    val Three = Color(0xFF0C9C8E)
    val Music = Color(0xFF7151EE)
    val Edit = Color(0xFFE58A00)
    val Good = Color(0xFF1A9354)

    fun studio(studio: String) = when (studio) {
        "draw" -> Draw
        "three" -> Three
        "music" -> Music
        else -> Edit
    }
}

private val KcTypography = Typography(
    headlineLarge = TextStyle(fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 34.sp),
    headlineMedium = TextStyle(fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 28.sp),
    titleLarge = TextStyle(fontSize = 20.sp, fontWeight = FontWeight.Bold, lineHeight = 24.sp),
    titleMedium = TextStyle(fontSize = 17.sp, fontWeight = FontWeight.SemiBold, lineHeight = 22.sp),
    bodyLarge = TextStyle(fontSize = 18.sp, fontWeight = FontWeight.Medium, lineHeight = 25.sp),
    bodyMedium = TextStyle(fontSize = 15.sp, lineHeight = 21.sp),
    labelLarge = TextStyle(fontSize = 15.sp, fontWeight = FontWeight.SemiBold),
    labelSmall = TextStyle(fontSize = 12.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.8.sp),
)

@Composable
fun KidsCreateTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Kc.Ink,
            onPrimary = Color.White,
            secondary = Kc.Draw,
            background = Kc.Bg,
            surface = Kc.Surface,
            onSurface = Kc.Ink,
            onBackground = Kc.Ink,
            surfaceVariant = Kc.Sunk,
            outline = Kc.Line,
        ),
        typography = KcTypography,
        content = content,
    )
}

/** A pulsing red ring that shows the child which button the step wants. */
fun Modifier.glow(on: Boolean, radius: Int = 14): Modifier = if (!on) this else composed {
    val t = rememberInfiniteTransition(label = "glow")
    val a by t.animateFloat(
        initialValue = 0.15f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(650), RepeatMode.Reverse), label = "glowAlpha",
    )
    this.border(4.dp, Kc.Draw.copy(alpha = a), RoundedCornerShape(radius.dp))
}
