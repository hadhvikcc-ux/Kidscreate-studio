package com.kidscreate.studio.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Construction
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Composable
fun ScreenHeader(title: String, onBack: (() -> Unit)? = null) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        if (onBack != null) {
            IconButton(
                onClick = onBack,
                modifier = Modifier.size(44.dp).background(Kc.Surface, RoundedCornerShape(14.dp))
                    .border(1.dp, Kc.Line, RoundedCornerShape(14.dp)),
            ) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") }
        }
        Text(title, style = MaterialTheme.typography.headlineMedium)
    }
}

@Composable
fun Card(modifier: Modifier = Modifier, color: Color = Kc.Surface, content: @Composable () -> Unit) {
    Box(
        modifier.fillMaxWidth().background(color, RoundedCornerShape(22.dp))
            .border(1.dp, Kc.Line, RoundedCornerShape(22.dp)).padding(16.dp),
    ) { content() }
}

/** Studios planned for Phase 2 of the roadmap. */
@Composable
fun ComingSoonScreen(title: String, color: Color, lines: List<String>, onBack: () -> Unit) {
    Column(
        Modifier.verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        ScreenHeader(title, onBack)
        Card(color = color) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Filled.Construction, null, tint = Color.White, modifier = Modifier.size(40.dp))
                Text("Coming soon!", style = MaterialTheme.typography.headlineMedium, color = Color.White)
                Text("This studio is being built. Here is what you'll be able to do:", color = Color.White)
            }
        }
        Card {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                lines.forEach { Text("•  $it") }
            }
        }
    }
}
