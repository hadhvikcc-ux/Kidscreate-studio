package com.kidscreate.studio.music

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kidscreate.studio.data.Progress
import com.kidscreate.studio.ui.Kc
import com.kidscreate.studio.ui.ScreenHeader
import kotlinx.coroutines.delay

private data class Row4(val key: String, val label: String, val color: Color)

private val ROWS = listOf(
    Row4("kick", "Kick", Kc.Draw),
    Row4("snare", "Snare", Kc.Edit),
    Row4("hat", "Hi-hat", Kc.Three),
    Row4("clap", "Clap", Kc.Music),
)

private val KEY_COLORS = listOf(Kc.Draw, Kc.Edit, Color(0xFFF5B700), Kc.Good, Kc.Three, Color(0xFF2B7BE4), Kc.Music, Color(0xFFD6458F))

/** Music Maker, Level 1: an 8-step beat grid and eight melody keys. */
@Composable
fun MusicScreen(progress: Progress, onBack: () -> Unit) {
    val synth = remember { Synth() }
    DisposableEffect(Unit) { onDispose { synth.release() } }

    // Starts with a simple pattern so there is something to hear straight away.
    val grid = remember {
        mutableStateListOf(
            *listOf(
                listOf(1, 0, 0, 0, 1, 0, 0, 0),
                listOf(0, 0, 1, 0, 0, 0, 1, 0),
                listOf(1, 1, 1, 1, 1, 1, 1, 1),
                listOf(0, 0, 0, 0, 0, 0, 0, 1),
            ).flatten().map { it == 1 }.toTypedArray(),
        )
    }
    var playing by remember { mutableStateOf(false) }
    var beat by remember { mutableIntStateOf(-1) }
    var bpm by remember { mutableIntStateOf(100) }
    val claps = (0 until 8).count { grid[3 * 8 + it] }

    LaunchedEffect(playing) {
        var s = 0
        while (playing) {
            beat = s
            ROWS.forEachIndexed { r, row -> if (grid[r * 8 + s]) synth.play(row.key) }
            s = (s + 1) % 8
            delay(60_000L / bpm / 2)
        }
        beat = -1
    }
    LaunchedEffect(claps) { if (claps >= 3) progress.addBadge("beat-builder") }

    Column(
        Modifier.verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        ScreenHeader("Music Maker", onBack)

        Column(
            Modifier.fillMaxWidth().background(Kc.Surface, RoundedCornerShape(22.dp)).padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Text("BEAT PADS · TAP SQUARES TO TURN THEM ON", style = MaterialTheme.typography.labelSmall, color = Kc.Muted)
            ROWS.forEachIndexed { r, row ->
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text(row.label, Modifier.width(56.dp), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    for (s in 0 until 8) {
                        val on = grid[r * 8 + s]
                        Box(
                            Modifier
                                .weight(1f)
                                .aspectRatio(1f)
                                .background(if (on) row.color else Kc.Sunk, RoundedCornerShape(8.dp))
                                .border(
                                    if (s == beat) 2.dp else 1.dp,
                                    if (s == beat) Kc.Ink else Kc.Line, RoundedCornerShape(8.dp),
                                )
                                .clickable {
                                    grid[r * 8 + s] = !on
                                    if (!on) synth.play(row.key)
                                },
                        )
                    }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = { playing = !playing },
                    colors = ButtonDefaults.buttonColors(containerColor = Kc.Music),
                ) {
                    Icon(if (playing) Icons.Filled.Stop else Icons.Filled.PlayArrow, null)
                    Text(if (playing) " Stop" else " Play beat")
                }
                OutlinedButton(onClick = { for (i in grid.indices) grid[i] = false }) { Text("Clear") }
                Text("Claps: $claps", fontSize = 13.sp, color = Kc.Muted)
            }
            Text("Speed: $bpm beats a minute", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Slider(value = bpm.toFloat(), onValueChange = { bpm = it.toInt() }, valueRange = 70f..150f)
        }

        Column(
            Modifier.fillMaxWidth().background(Kc.Surface, RoundedCornerShape(22.dp)).padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Text("MELODY KEYS · THESE 8 NOTES ALWAYS SOUND NICE TOGETHER", style = MaterialTheme.typography.labelSmall, color = Kc.Muted)
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                synth.notes.forEachIndexed { i, (letter, sargam, _) ->
                    Column(
                        Modifier
                            .weight(1f)
                            .height(110.dp)
                            .background(Kc.Sunk, RoundedCornerShape(bottomStart = 12.dp, bottomEnd = 12.dp))
                            .border(1.dp, Kc.Line, RoundedCornerShape(bottomStart = 12.dp, bottomEnd = 12.dp))
                            .clickable { synth.play("note$i") },
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Bottom,
                    ) {
                        Box(Modifier.fillMaxWidth().height(6.dp).background(KEY_COLORS[i]))
                        Spacer(Modifier.weight(1f))
                        Text(letter, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        Text(sargam, fontSize = 10.sp, color = Kc.Muted, modifier = Modifier.padding(bottom = 6.dp))
                    }
                }
            }
        }
        Text(
            "Challenge: make a beat with 3 claps in it to earn the Beat Builder badge.",
            color = Kc.Muted, fontSize = 13.sp,
        )
    }
}
