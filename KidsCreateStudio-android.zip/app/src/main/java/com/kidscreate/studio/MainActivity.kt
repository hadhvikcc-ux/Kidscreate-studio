package com.kidscreate.studio

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.kidscreate.studio.data.CartoonStore
import com.kidscreate.studio.data.Lesson
import com.kidscreate.studio.data.LessonRepository
import com.kidscreate.studio.data.Progress
import com.kidscreate.studio.draw.FlipbookState
import com.kidscreate.studio.lesson.LessonScreen
import com.kidscreate.studio.music.MusicScreen
import com.kidscreate.studio.ui.ComingSoonScreen
import com.kidscreate.studio.ui.DrawStudioScreen
import com.kidscreate.studio.ui.HomeScreen
import com.kidscreate.studio.ui.Kc
import com.kidscreate.studio.ui.KidsCreateTheme
import com.kidscreate.studio.ui.LearnScreen
import com.kidscreate.studio.ui.MoviesScreen
import com.kidscreate.studio.ui.ParentScreen
import com.kidscreate.studio.ui.ProfileScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { KidsCreateTheme { App() } }
    }
}

sealed interface Screen {
    data object Home : Screen
    data object Learn : Screen
    data object Movies : Screen
    data object Profile : Screen
    data object Parent : Screen
    data object Draw : Screen
    data object Music : Screen
    data object Three : Screen
    data object Edit : Screen
    data class LessonPlay(val id: String) : Screen
}

@Composable
fun App() {
    val context = LocalContext.current
    val progress = remember { Progress(context) }
    val lessons = remember { LessonRepository.all(context) }
    val drawBook = remember { FlipbookState() }
    var screen by remember { mutableStateOf<Screen>(if (progress.hasProfile) Screen.Home else Screen.Profile) }
    var lessonKey by remember { mutableStateOf(0) }

    val drawLessons = lessons.filter { it.studio == "draw" }
    val nextLesson: Lesson? = drawLessons.firstOrNull { it.id !in progress.completed } ?: drawLessons.lastOrNull()
    val tab = when (screen) {
        Screen.Home, Screen.Profile, Screen.Draw, Screen.Music, Screen.Three, Screen.Edit -> 0
        Screen.Learn, is Screen.LessonPlay -> 1
        Screen.Movies, Screen.Parent -> 2
    }

    BackHandler(enabled = screen != Screen.Home) {
        screen = when (screen) {
            Screen.Parent -> Screen.Movies
            is Screen.LessonPlay -> Screen.Learn
            else -> Screen.Home
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = Kc.Bg,
        bottomBar = {
            if (screen != Screen.Profile || progress.hasProfile) {
                NavigationBar(containerColor = Kc.Surface) {
                    NavigationBarItem(selected = tab == 0, onClick = { screen = Screen.Home }, icon = { Icon(Icons.Filled.Home, null) }, label = { Text("Home") })
                    NavigationBarItem(selected = tab == 1, onClick = { screen = Screen.Learn }, icon = { Icon(Icons.Filled.Map, null) }, label = { Text("Learn") })
                    NavigationBarItem(selected = tab == 2, onClick = { screen = Screen.Movies }, icon = { Icon(Icons.Filled.Movie, null) }, label = { Text("My Movies") })
                }
            }
        },
    ) { inner ->
        Box(Modifier.padding(inner).fillMaxSize().background(Kc.Bg)) {
            when (val s = screen) {
                Screen.Home -> HomeScreen(
                    progress = progress,
                    next = nextLesson,
                    onLesson = { lessonKey++; screen = Screen.LessonPlay(it.id) },
                    onStudio = { id ->
                        screen = when (id) {
                            "draw" -> Screen.Draw
                            "music" -> Screen.Music
                            "three" -> Screen.Three
                            else -> Screen.Edit
                        }
                    },
                    onProfile = { screen = Screen.Profile },
                )
                Screen.Learn -> LearnScreen(progress, lessons) { lessonKey++; screen = Screen.LessonPlay(it.id) }
                Screen.Movies -> MoviesScreen(
                    onOpen = { CartoonStore.loadInto(it, drawBook); screen = Screen.Draw },
                    onParent = { screen = Screen.Parent },
                )
                Screen.Parent -> ParentScreen(progress, lessons) { screen = Screen.Movies }
                Screen.Profile -> ProfileScreen(
                    progress,
                    onDone = { screen = Screen.Home },
                    onBack = if (progress.hasProfile) ({ screen = Screen.Home }) else null,
                )
                Screen.Draw -> DrawStudioScreen(drawBook, progress) { screen = Screen.Home }
                Screen.Music -> MusicScreen(progress) { screen = Screen.Home }
                Screen.Three -> ComingSoonScreen(
                    "3D Builder", Kc.Three,
                    listOf(
                        "Build with cubes, balls, cones and tubes",
                        "Paint them any colour",
                        "Spin the camera with two fingers",
                        "Make shapes jump and move along a path",
                    ),
                ) { screen = Screen.Home }
                Screen.Edit -> ComingSoonScreen(
                    "Movie Editor", Kc.Edit,
                    listOf(
                        "Put your cartoons in order",
                        "Add a title card",
                        "Add your beat from Music Maker",
                        "Save one movie to share with family",
                    ),
                ) { screen = Screen.Home }
                is Screen.LessonPlay -> {
                    val lesson = lessons.firstOrNull { it.id == s.id }
                    if (lesson == null) {
                        LaunchedEffect(s.id) { screen = Screen.Learn }
                    } else {
                        androidx.compose.runtime.key(s.id, lessonKey) {
                            LessonScreen(
                                lesson = lesson,
                                progress = progress,
                                onBack = { screen = Screen.Learn },
                                onDone = {
                                    val idx = drawLessons.indexOf(lesson)
                                    val after = drawLessons.getOrNull(idx + 1)
                                    if (after != null) { lessonKey++; screen = Screen.LessonPlay(after.id) } else screen = Screen.Learn
                                },
                            )
                        }
                    }
                }
            }
        }
    }
}
