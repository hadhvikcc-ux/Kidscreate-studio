package com.kidscreate.studio.music

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin
import kotlin.random.Random

/**
 * Tiny built-in sound kit. Every sound is made in code at start-up, so the app needs no audio files
 * and works offline. Each sound lives in its own static AudioTrack for instant replay.
 */
class Synth {
    private val rate = 22050
    private val tracks = mutableMapOf<String, AudioTrack>()

    /** Pentatonic notes (C D E G A) — any mix of them sounds nice. Sa Re Ga Pa Dha in sargam. */
    val notes = listOf(
        Triple("C", "Sa", 261.63), Triple("D", "Re", 293.66), Triple("E", "Ga", 329.63), Triple("G", "Pa", 392.0),
        Triple("A", "Dha", 440.0), Triple("C", "Sa", 523.25), Triple("D", "Re", 587.33), Triple("E", "Ga", 659.25),
    )

    init {
        put("kick", render(0.32) { t -> sin(2 * PI * (45 * t + (105.0 / 9.0) * (1 - exp(-9 * t)))) * exp(-9 * t) })
        put("snare", render(0.2) { t -> (noise() * 0.7 + sin(2 * PI * 185 * t) * 0.3) * exp(-18 * t) })
        var last = 0.0
        put("hat", render(0.06) { t -> val n = noise(); val hp = n - last; last = n; hp * 0.5 * exp(-60 * t) })
        put("clap", render(0.18) { t ->
            val burst = if (t < 0.012 || (t in 0.014..0.026) || t > 0.03) 1.0 else 0.2
            noise() * burst * exp(-22 * t) * 0.8
        })
        notes.forEachIndexed { i, (_, _, f) ->
            put("note$i", render(0.7) { t ->
                val tri = (2 / PI) * kotlin.math.asin(sin(2 * PI * f * t))
                (tri * 0.8 + sin(4 * PI * f * t) * 0.15) * exp(-4.5 * t) * 0.6
            })
        }
    }

    private fun noise() = Random.nextDouble(-1.0, 1.0)

    private fun render(seconds: Double, wave: (Double) -> Double): ShortArray {
        val n = (seconds * rate).toInt()
        return ShortArray(n) { i ->
            val fadeIn = (i / 40.0).coerceAtMost(1.0)
            (wave(i.toDouble() / rate) * fadeIn * 30000).coerceIn(-32767.0, 32767.0).toInt().toShort()
        }
    }

    private fun put(name: String, pcm: ShortArray) {
        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build(),
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(rate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build(),
            )
            .setTransferMode(AudioTrack.MODE_STATIC)
            .setBufferSizeInBytes(pcm.size * 2)
            .build()
        track.write(pcm, 0, pcm.size)
        tracks[name] = track
    }

    fun play(name: String) {
        val t = tracks[name] ?: return
        runCatching {
            if (t.playState == AudioTrack.PLAYSTATE_PLAYING) t.stop()
            t.reloadStaticData()
            t.play()
        }
    }

    fun release() {
        tracks.values.forEach { runCatching { it.release() } }
        tracks.clear()
    }
}
