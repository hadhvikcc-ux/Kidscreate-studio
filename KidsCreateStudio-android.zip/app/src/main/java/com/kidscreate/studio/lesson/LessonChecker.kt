package com.kidscreate.studio.lesson

import androidx.compose.ui.geometry.Offset
import com.kidscreate.studio.draw.CANVAS_ASPECT
import com.kidscreate.studio.draw.FlipbookState
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.floatOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive

internal fun JsonObject.str(k: String): String? = (this[k] as? JsonPrimitive)?.contentOrNull
internal fun JsonObject.num(k: String): Float? = (this[k] as? JsonPrimitive)?.floatOrNull
internal fun JsonObject.int(k: String): Int? = (this[k] as? JsonPrimitive)?.intOrNull
internal fun JsonObject.bool(k: String): Boolean? = (this[k] as? JsonPrimitive)?.booleanOrNull

/** Where the drawing on a frame sits: its centre and bounding box, in 0..1 canvas units. */
data class FrameStats(val cx: Float, val cy: Float, val minX: Float, val maxX: Float, val minY: Float, val maxY: Float) {
    val w get() = maxX - minX
    val h get() = maxY - minY
}

/**
 * Decides whether the child has done what a step asks. Each check in the lesson JSON has a "type";
 * unknown types pass, so an older app never blocks a child on a newer lesson file.
 */
object LessonChecker {

    private fun frameIndex(c: JsonObject, fb: FlipbookState, key: String = "frame"): Int? {
        val raw = c[key]?.jsonPrimitive ?: return null
        if (raw.contentOrNull == "last") return fb.frames.lastIndex
        return raw.intOrNull
    }

    fun stats(fb: FlipbookState, index: Int?): FrameStats? {
        if (index == null || index !in fb.frames.indices) return null
        val pts: List<Offset> = fb.frames[index].strokes.filter { !it.eraser }.flatMap { it.points }
        if (pts.isEmpty()) return null
        var minX = 1f; var maxX = 0f; var minY = 1f; var maxY = 0f
        var sx = 0f; var sy = 0f
        for (p in pts) {
            sx += p.x; sy += p.y
            if (p.x < minX) minX = p.x
            if (p.x > maxX) maxX = p.x
            if (p.y < minY) minY = p.y
            if (p.y > maxY) maxY = p.y
        }
        return FrameStats(sx / pts.size, sy / pts.size, minX, maxX, minY, maxY)
    }

    private fun colorsOn(fb: FlipbookState, index: Int?): Set<String> {
        val frames = if (index == null) fb.frames.toList() else listOfNotNull(fb.frames.getOrNull(index))
        return frames.flatMap { f -> f.strokes.filter { !it.eraser && it.points.isNotEmpty() }.map { it.colorName } }.toSet()
    }

    fun passes(c: JsonObject, fb: FlipbookState): Boolean {
        val by = c.num("by") ?: 0f
        return when (c.str("type")) {
            "all" -> (c["of"] as? JsonArray)?.all { passes(it.jsonObject, fb) } ?: true

            "drawingOn" -> {
                val s = stats(fb, frameIndex(c, fb)) ?: return false
                (c.num("minX")?.let { s.cx >= it } ?: true) &&
                    (c.num("maxX")?.let { s.cx <= it } ?: true) &&
                    (c.num("minY")?.let { s.cy >= it } ?: true) &&
                    (c.num("maxY")?.let { s.cy <= it } ?: true)
            }

            "frameCount" -> fb.frames.size >= (c.int("min") ?: 1)

            "below", "above", "rightOf", "leftOf" -> {
                val a = stats(fb, frameIndex(c, fb)) ?: return false
                val b = stats(fb, frameIndex(c, fb, "than")) ?: return false
                when (c.str("type")) {
                    "below" -> a.cy > b.cy + by
                    "above" -> a.cy < b.cy - by
                    "rightOf" -> a.cx > b.cx + by
                    else -> a.cx < b.cx - by
                }
            }

            "taller" -> {
                val a = stats(fb, frameIndex(c, fb)) ?: return false
                val b = stats(fb, frameIndex(c, fb, "than")) ?: return false
                a.h > b.h + 0.03f
            }

            // Compare in screen pixels: a 0..1 height is shorter on screen than a 0..1 width.
            "tallerThanWide" -> stats(fb, frameIndex(c, fb))?.let { it.h > it.w * CANVAS_ASPECT * 1.15f } ?: false
            "widerThanTall" -> stats(fb, frameIndex(c, fb))?.let { it.w * CANVAS_ASPECT > it.h * 1.15f } ?: false

            "colorUsed" -> (c.str("color") ?: "") in colorsOn(fb, frameIndex(c, fb))
            "colorsUsed" -> colorsOn(fb, frameIndex(c, fb)).size >= (c.int("min") ?: 2)

            "strokes" -> {
                val i = frameIndex(c, fb) ?: return false
                (fb.frames.getOrNull(i)?.strokes?.count { !it.eraser } ?: 0) >= (c.int("min") ?: 1)
            }
            "strokesAdded" -> {
                val i = frameIndex(c, fb) ?: return false
                (fb.frames.getOrNull(i)?.strokesAdded ?: 0) >= (c.int("min") ?: 1)
            }
            "toolUsed" -> {
                val i = frameIndex(c, fb) ?: return false
                c.str("tool") != "eraser" || fb.frames.getOrNull(i)?.eraserUsed == true
            }
            "holdAtLeast" -> {
                val i = frameIndex(c, fb) ?: return false
                (fb.frames.getOrNull(i)?.hold ?: 1) >= (c.int("min") ?: 2)
            }

            "played" -> {
                val p = fb.lastPlay ?: return false
                c.bool("pingpong")?.let { it == p.pingPong } ?: true
            }
            "fpsAtMost" -> fb.fps <= (c.int("fps") ?: 4)
            "playedAtFpsAtMost" -> fb.lastPlay?.let { it.fps <= (c.int("fps") ?: 4) } ?: false
            "playedAtFpsAtLeast" -> fb.lastPlay?.let { it.fps >= (c.int("fps") ?: 10) } ?: false

            "acknowledged" -> fb.acknowledged
            "saved" -> fb.saved
            else -> true
        }
    }
}
