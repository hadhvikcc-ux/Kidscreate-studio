package com.kidscreate.studio.data

import android.content.Context
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject

/** One lesson, loaded from assets/lessons/<id>.json. */
@Serializable
data class Lesson(
    val id: String,
    val studio: String,
    val level: Int,
    val order: Int,
    val title: String,
    val minutes: Int,
    val skill: String = "",
    val badge: String? = null,
    val intro: String,
    val steps: List<Step>,
    val challenge: String = "",
)

/**
 * One step card. [check] and [auto] stay as raw JSON so new check types can be
 * added to lesson files and to LessonChecker without changing this model.
 */
@Serializable
data class Step(
    val say: String,
    val check: JsonObject,
    val glow: String? = null,
    val ghost: Ghost? = null,
    val pro: String? = null,
    val auto: JsonObject? = null,
)

/** A dotted hint shape, in canvas units (0..1 across and down). */
@Serializable
data class Ghost(val x: Float, val y: Float, val rx: Float, val ry: Float)

object LessonRepository {
    val json = Json { ignoreUnknownKeys = true }
    private var cache: List<Lesson>? = null

    fun all(context: Context): List<Lesson> {
        cache?.let { return it }
        val files = context.assets.list("lessons").orEmpty()
            .filter { it.endsWith(".json") && !it.startsWith("index") }
        val lessons = files.mapNotNull { name ->
            runCatching {
                val text = context.assets.open("lessons/$name").bufferedReader().use { it.readText() }
                json.decodeFromString(Lesson.serializer(), text)
            }.getOrNull()
        }.sortedWith(compareBy({ it.studio }, { it.level }, { it.order }))
        cache = lessons
        return lessons
    }

    fun byId(context: Context, id: String): Lesson? = all(context).firstOrNull { it.id == id }
}
