package com.kidscreate.studio.draw

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.HourglassBottom
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilledIconToggleButton
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kidscreate.studio.data.Ghost
import com.kidscreate.studio.ui.Kc
import com.kidscreate.studio.ui.glow
import kotlinx.coroutines.delay
import androidx.compose.ui.graphics.drawscope.Stroke as DrawStroke

/** Draws one frame's strokes. Call inside an offscreen layer so the eraser only clears this frame. */
fun DrawScope.drawFrame(frame: Frame) {
    val w = size.width
    val h = size.height
    for (s in frame.strokes) {
        val color = colorOf(s.colorName)
        val sw = s.width * w
        val blend = if (s.eraser) BlendMode.Clear else BlendMode.SrcOver
        if (s.points.size == 1) {
            drawCircle(color, sw / 2f, Offset(s.points[0].x * w, s.points[0].y * h), blendMode = blend)
        } else if (s.points.size > 1) {
            val path = Path()
            s.points.forEachIndexed { i, p -> if (i == 0) path.moveTo(p.x * w, p.y * h) else path.lineTo(p.x * w, p.y * h) }
            drawPath(path, color, style = DrawStroke(width = sw, cap = StrokeCap.Round, join = StrokeJoin.Round), blendMode = blend)
        }
    }
}

private fun DrawScope.drawPaper() {
    drawRect(Color.White)
    val groundTop = size.height * (1f - 36f / 420f)
    drawRect(Color(0xFFE9EEF9), topLeft = Offset(0f, groundTop), size = Size(size.width, size.height - groundTop))
    drawLine(Color(0xFFC9D3EC), Offset(0f, groundTop), Offset(size.width, groundTop), strokeWidth = 3f)
}

/**
 * The flipbook: tools, paper, page strip and playback. Used both in lessons and in the free Draw studio.
 * [glow] names the control a lesson step wants the child to use (e.g. "action.addFrame").
 */
@Composable
fun FlipbookStudio(
    fb: FlipbookState,
    modifier: Modifier = Modifier,
    glow: String? = null,
    ghost: Ghost? = null,
    onSave: (() -> Unit)? = null,
) {
    LaunchedEffect(fb.playing) {
        var k = 0
        while (fb.playing) {
            val seq = fb.playSequence()
            if (seq.isEmpty()) break
            fb.showIndex = seq[k % seq.size]
            k++
            delay(1000L / fb.fps.coerceAtLeast(1))
        }
    }

    Column(modifier, verticalArrangement = Arrangement.spacedBy(10.dp)) {
        // Tools and colours
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            FilledIconToggleButton(
                checked = fb.tool == Tool.Pen, onCheckedChange = { fb.tool = Tool.Pen },
                modifier = Modifier.glow(glow == "tool.pen", 24),
            ) { Icon(Icons.Filled.Edit, contentDescription = "Pencil") }
            FilledIconToggleButton(
                checked = fb.tool == Tool.Eraser, onCheckedChange = { fb.tool = Tool.Eraser },
                modifier = Modifier.glow(glow == "tool.eraser", 24),
            ) { Icon(Icons.Filled.CleaningServices, contentDescription = "Eraser") }
            FilledIconToggleButton(checked = fb.onion, onCheckedChange = { fb.onion = it }) {
                Icon(Icons.Filled.Layers, contentDescription = "Onion-skin")
            }
            Spacer(Modifier.width(4.dp))
            PALETTE.forEach { (name, color) ->
                val picked = fb.colorName == name && fb.tool == Tool.Pen
                Box(
                    Modifier
                        .size(34.dp)
                        .glow(glow == "color.$name", 20)
                        .padding(2.dp)
                        .clip(CircleShape)
                        .background(color)
                        .border(if (picked) 4.dp else 0.dp, if (picked) Kc.Ink else Color.Transparent, CircleShape)
                        .clickable { fb.colorName = name; fb.tool = Tool.Pen },
                )
            }
        }

        // Paper
        val shown = if (fb.playing) fb.showIndex.coerceIn(0, fb.frames.lastIndex) else fb.current
        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(CANVAS_ASPECT)
                .glow(glow == "canvas", 20)
                .clip(RoundedCornerShape(18.dp))
                .border(1.dp, Kc.Line, RoundedCornerShape(18.dp))
                .pointerInput(fb) {
                    awaitEachGesture {
                        val down = awaitFirstDown()
                        val w = size.width.toFloat()
                        val h = size.height.toFloat()
                        fun norm(p: Offset) = Offset((p.x / w).coerceIn(0f, 1f), (p.y / h).coerceIn(0f, 1f))
                        fb.beginStroke(norm(down.position))
                        down.consume()
                        while (true) {
                            val event = awaitPointerEvent()
                            val change = event.changes.firstOrNull { it.id == down.id } ?: break
                            if (!change.pressed) break
                            fb.addPoint(norm(change.position))
                            change.consume()
                        }
                        fb.endStroke()
                    }
                },
        ) {
            Canvas(Modifier.fillMaxSize()) { drawPaper() }
            if (!fb.playing && fb.onion && fb.current > 0) {
                Canvas(Modifier.fillMaxSize().graphicsLayer(alpha = 0.22f, compositingStrategy = CompositingStrategy.Offscreen)) {
                    drawFrame(fb.frames[fb.current - 1])
                }
            }
            Canvas(Modifier.fillMaxSize().graphicsLayer(compositingStrategy = CompositingStrategy.Offscreen)) {
                drawFrame(fb.frames[shown])
            }
            if (ghost != null && !fb.playing) {
                Canvas(Modifier.fillMaxSize()) {
                    val w = size.width
                    val h = size.height
                    drawOval(
                        Kc.Draw,
                        topLeft = Offset((ghost.x - ghost.rx) * w, (ghost.y - ghost.ry) * h),
                        size = Size(ghost.rx * 2 * w, ghost.ry * 2 * h),
                        style = DrawStroke(width = 5f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(18f, 14f))),
                    )
                }
            }
            Text(
                "Page ${shown + 1} of ${fb.frames.size}",
                Modifier.align(Alignment.TopEnd).padding(8.dp)
                    .background(Color.White.copy(alpha = 0.9f), RoundedCornerShape(8.dp))
                    .padding(horizontal = 8.dp, vertical = 2.dp),
                fontSize = 12.sp, color = Kc.Muted, fontWeight = FontWeight.SemiBold,
            )
        }

        // Page strip
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            itemsIndexed(fb.frames) { i, frame ->
                val sel = i == fb.current
                Box(
                    Modifier
                        .width(68.dp)
                        .aspectRatio(CANVAS_ASPECT)
                        .clip(RoundedCornerShape(10.dp))
                        .border(if (sel) 3.dp else 1.dp, if (sel) Kc.Draw else Kc.Line, RoundedCornerShape(10.dp))
                        .clickable { fb.select(i) },
                ) {
                    Canvas(Modifier.fillMaxSize()) { drawRect(Color.White) }
                    Canvas(Modifier.fillMaxSize().graphicsLayer(compositingStrategy = CompositingStrategy.Offscreen)) { drawFrame(frame) }
                    Text(
                        if (frame.hold > 1) "${i + 1} ×${frame.hold}" else "${i + 1}",
                        Modifier.align(Alignment.BottomStart).padding(3.dp), fontSize = 10.sp, color = Kc.Muted,
                    )
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    SmallAction("Add page", glow == "action.addFrame") { fb.addFrame() }
                    SmallAction("Copy page", glow == "action.copyFrame", copy = true) { fb.copyFrame() }
                }
            }
        }

        // Play controls
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Button(
                onClick = { fb.togglePlay() },
                colors = ButtonDefaults.buttonColors(containerColor = Kc.Draw),
                modifier = Modifier.glow(glow == "action.play", 24),
            ) {
                Icon(if (fb.playing) Icons.Filled.Stop else Icons.Filled.PlayArrow, null)
                Spacer(Modifier.width(6.dp))
                Text(if (fb.playing) "Stop" else "Play")
            }
            OutlinedButton(onClick = { fb.holdMore() }, modifier = Modifier.glow(glow == "action.hold", 24)) {
                Icon(Icons.Filled.HourglassBottom, null)
                Text(" Hold")
            }
            OutlinedButton(onClick = { fb.clearFrame() }) { Text("Clear page") }
            OutlinedButton(onClick = { fb.deleteFrame() }) { Icon(Icons.Filled.Delete, contentDescription = "Delete page") }
        }

        // Speed and bounce
        Column(
            Modifier.fillMaxWidth().glow(glow == "control.fps" || glow == "action.pingpong", 16)
                .background(Kc.Surface, RoundedCornerShape(16.dp)).padding(12.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Speed: ${fb.fps} pictures a second", Modifier.weight(1f), fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Snail", fontSize = 12.sp, color = Kc.Muted)
                Slider(
                    value = fb.fps.toFloat(), onValueChange = { fb.fps = it.toInt() },
                    valueRange = 2f..16f, steps = 13, modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
                )
                Text("Rabbit", fontSize = 12.sp, color = Kc.Muted)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Bounce back at the end", Modifier.weight(1f), fontSize = 14.sp)
                Switch(checked = fb.pingPong, onCheckedChange = { fb.pingPong = it })
            }
        }

        if (onSave != null) {
            Button(
                onClick = onSave,
                modifier = Modifier.fillMaxWidth().glow(glow == "action.save", 24),
                colors = ButtonDefaults.buttonColors(containerColor = Kc.Ink),
            ) {
                Icon(Icons.Filled.Save, null)
                Spacer(Modifier.width(6.dp))
                Text("Save to My Movies")
            }
        }
    }
}

@Composable
private fun SmallAction(label: String, glowing: Boolean, copy: Boolean = false, onClick: () -> Unit) {
    Box(
        Modifier
            .size(48.dp)
            .glow(glowing, 12)
            .clip(RoundedCornerShape(12.dp))
            .border(2.dp, Kc.Muted, RoundedCornerShape(12.dp))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(if (copy) Icons.Filled.ContentCopy else Icons.Filled.Add, contentDescription = label, tint = Kc.Muted)
    }
}
