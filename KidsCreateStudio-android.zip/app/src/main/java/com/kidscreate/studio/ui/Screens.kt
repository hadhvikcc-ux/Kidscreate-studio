package com.kidscreate.studio.ui

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Brush
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.ViewInAr
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kidscreate.studio.data.ALL_BADGES
import com.kidscreate.studio.data.CartoonStore
import com.kidscreate.studio.data.Lesson
import com.kidscreate.studio.data.Progress
import com.kidscreate.studio.data.SavedCartoon
import com.kidscreate.studio.draw.CANVAS_ASPECT
import com.kidscreate.studio.draw.FlipbookState
import com.kidscreate.studio.draw.FlipbookStudio
import com.kidscreate.studio.draw.Frame
import com.kidscreate.studio.draw.drawFrame
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

val AVATAR_COLORS = listOf(Kc.Draw, Kc.Three, Kc.Music, Kc.Edit, Color(0xFF2B7BE4), Color(0xFFD6458F))
val GRADES = listOf("4-5" to "Grade 4–5", "6-8" to "Grade 6–8", "9-10" to "Grade 9–10")

@Composable
fun Avatar(index: Int, size: Int = 54) {
    Box(
        Modifier.size(size.dp).background(AVATAR_COLORS[index % AVATAR_COLORS.size], RoundedCornerShape((size / 3).dp)),
        contentAlignment = Alignment.Center,
    ) { Icon(Icons.Filled.Face, null, tint = Color.White, modifier = Modifier.size((size * 0.7f).dp)) }
}

// ---------------- Home ----------------

@Composable
fun HomeScreen(
    progress: Progress,
    next: Lesson?,
    onLesson: (Lesson) -> Unit,
    onStudio: (String) -> Unit,
    onProfile: () -> Unit,
) {
    Column(
        Modifier.verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(Modifier.clickable(onClick = onProfile)) { Avatar(progress.avatar) }
            Column(Modifier.weight(1f)) {
                Text("Welcome back", color = Kc.Muted, fontSize = 13.sp)
                Text("Hi ${progress.name}!", style = MaterialTheme.typography.headlineLarge)
            }
            Text(
                GRADES.first { it.first == progress.grade }.second,
                Modifier.background(Kc.Surface, RoundedCornerShape(50)).border(1.dp, Kc.Line, RoundedCornerShape(50))
                    .clickable(onClick = onProfile).padding(horizontal = 10.dp, vertical = 4.dp),
                fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
            )
        }

        if (next != null) {
            Row(
                Modifier.fillMaxWidth().background(Kc.Draw, RoundedCornerShape(24.dp)).clickable { onLesson(next) }.padding(18.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Text("NEXT LESSON", style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.85f))
                    Text(next.title, style = MaterialTheme.typography.headlineMedium, color = Color.White)
                    Text("Draw & Animate · ${next.steps.size} steps · ${next.minutes} min", color = Color.White, fontSize = 13.sp)
                }
                Box(Modifier.size(56.dp).background(Color.White, CircleShape), contentAlignment = Alignment.Center) {
                    Icon(Icons.AutoMirrored.Filled.ArrowForward, null, tint = Kc.Draw)
                }
            }
        }

        Text("YOUR STUDIOS", style = MaterialTheme.typography.labelSmall, color = Kc.Muted)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StudioTile("Draw & Animate", "Flipbooks and cartoons", Icons.Filled.Brush, Kc.Draw, Modifier.weight(1f)) { onStudio("draw") }
            StudioTile("3D Builder", "Build and move shapes", Icons.Filled.ViewInAr, Kc.Three, Modifier.weight(1f)) { onStudio("three") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StudioTile("Music Maker", "Beats and melodies", Icons.Filled.MusicNote, Kc.Music, Modifier.weight(1f)) { onStudio("music") }
            StudioTile("Movie Editor", "Make your movie", Icons.Filled.Movie, Kc.Edit, Modifier.weight(1f)) { onStudio("edit") }
        }

        Text("BADGES", style = MaterialTheme.typography.labelSmall, color = Kc.Muted)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            ALL_BADGES.forEach { b ->
                val has = b.id in progress.badges
                Column(Modifier.width(78.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        Modifier.size(60.dp).background(if (has) Kc.Edit else Kc.Line, CircleShape),
                        contentAlignment = Alignment.Center,
                    ) { Icon(if (has) Icons.Filled.EmojiEvents else Icons.Filled.Lock, null, tint = if (has) Color.White else Kc.Muted) }
                    Text(b.name, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = Kc.Muted, maxLines = 2)
                }
            }
        }
    }
}

@Composable
private fun StudioTile(title: String, sub: String, icon: ImageVector, color: Color, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier.heightIn(min = 132.dp).background(color, RoundedCornerShape(22.dp)).clickable(onClick = onClick).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Icon(icon, null, tint = Color.White, modifier = Modifier.size(38.dp))
        Text(title, color = Color.White, style = MaterialTheme.typography.titleLarge)
        Text(sub, color = Color.White, fontSize = 12.sp)
    }
}

// ---------------- Learn map ----------------

@Composable
fun LearnScreen(progress: Progress, lessons: List<Lesson>, onLesson: (Lesson) -> Unit) {
    val context = LocalContext.current
    Column(
        Modifier.verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        ScreenHeader("Learn")
        Text("Draw & Animate · Level 1", color = Kc.Muted, fontWeight = FontWeight.SemiBold)
        lessons.filter { it.studio == "draw" }.forEachIndexed { i, l ->
            val open = progress.isUnlocked(l, lessons)
            val done = l.id in progress.completed
            val shift = listOf(0, 60, 110, 50)[i % 4]
            Row(
                Modifier.padding(start = shift.dp).clickable {
                    if (open) onLesson(l) else Toast.makeText(context, "Finish the lesson before this one to unlock it", Toast.LENGTH_SHORT).show()
                },
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Box(
                    Modifier.size(66.dp).background(if (open) Kc.Draw else Kc.Line, CircleShape),
                    contentAlignment = Alignment.Center,
                ) {
                    when {
                        done -> Icon(Icons.Filled.CheckCircle, null, tint = Color.White, modifier = Modifier.size(32.dp))
                        open -> Text("${l.order}", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 24.sp)
                        else -> Icon(Icons.Filled.Lock, null, tint = Kc.Muted)
                    }
                }
                Column {
                    Text(l.title, style = MaterialTheme.typography.titleLarge)
                    Text("${l.steps.size} steps · ${l.minutes} min" + if (done) " · done" else "", fontSize = 12.sp, color = Kc.Muted)
                }
            }
        }
        Spacer(Modifier.padding(4.dp))
        Text("3D, Music and Movie lessons arrive in the next update.", color = Kc.Muted, fontSize = 13.sp)
    }
}

// ---------------- Free draw studio ----------------

@Composable
fun DrawStudioScreen(fb: FlipbookState, progress: Progress, onBack: () -> Unit) {
    val context = LocalContext.current
    var askTitle by remember { mutableStateOf(false) }
    var title by remember { mutableStateOf("") }
    Column(
        Modifier.verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        ScreenHeader("Draw & Animate", onBack)
        FlipbookStudio(fb, onSave = { askTitle = true })
        Text(
            "Each page is one picture. Change it a little on every page, then press Play. Your eyes join them into movement.",
            color = Kc.Muted, fontSize = 13.sp,
        )
    }
    if (askTitle) {
        AlertDialog(
            onDismissRequest = { askTitle = false },
            title = { Text("Name your cartoon") },
            text = { OutlinedTextField(value = title, onValueChange = { title = it.take(28) }, singleLine = true, placeholder = { Text("My Cartoon") }) },
            confirmButton = {
                Button(onClick = {
                    CartoonStore.save(context, title.ifBlank { "Cartoon by ${progress.name}" }, fb)
                    fb.saved = true
                    askTitle = false
                    Toast.makeText(context, "Saved to My Movies", Toast.LENGTH_SHORT).show()
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { askTitle = false }) { Text("Cancel") } },
        )
    }
}

// ---------------- My Movies ----------------

@Composable
fun MoviesScreen(onOpen: (SavedCartoon) -> Unit, onParent: () -> Unit) {
    val context = LocalContext.current
    var version by remember { mutableIntStateOf(0) }
    val items = remember(version) { CartoonStore.list(context) }
    var gate by remember { mutableStateOf(false) }
    var toDelete by remember { mutableStateOf<File?>(null) }

    Column(
        Modifier.verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        ScreenHeader("My Movies")
        if (items.isEmpty()) {
            Card { Text("No cartoons yet. Finish a lesson or make one in Draw & Animate, then tap Save.") }
        }
        items.forEach { (file, c) ->
            Row(
                Modifier.fillMaxWidth().background(Kc.Surface, RoundedCornerShape(20.dp)).clickable { onOpen(c) }.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Poster(c, Modifier.width(96.dp))
                Column(Modifier.weight(1f)) {
                    Text(c.title, style = MaterialTheme.typography.titleMedium)
                    Text(
                        "${c.frames.size} pages · " + SimpleDateFormat("d MMM", Locale.getDefault()).format(Date(c.savedAt)),
                        fontSize = 12.sp, color = Kc.Muted,
                    )
                }
                Icon(Icons.Filled.PlayArrow, null, tint = Kc.Draw)
                IconButton(onClick = { toDelete = file }) { Icon(Icons.Filled.Delete, contentDescription = "Delete") }
            }
        }
        Card {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("FOR GROWN-UPS", style = MaterialTheme.typography.labelSmall, color = Kc.Muted)
                Text("Progress, read-aloud and settings live in the Parent area.")
                OutlinedButton(onClick = { gate = true }) {
                    Icon(Icons.Filled.Lock, null)
                    Text(" Parent area")
                }
            }
        }
    }

    toDelete?.let { f ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("Delete this cartoon?") },
            text = { Text("It will be gone for good.") },
            confirmButton = {
                Button(
                    onClick = { CartoonStore.delete(f); toDelete = null; version++ },
                    colors = ButtonDefaults.buttonColors(containerColor = Kc.Draw),
                ) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Keep it") } },
        )
    }
    if (gate) ParentGate(onPass = { gate = false; onParent() }, onCancel = { gate = false })
}

@Composable
private fun Poster(c: SavedCartoon, modifier: Modifier) {
    val frame = remember(c) {
        Frame().also { f ->
            c.frames.firstOrNull()?.strokes?.forEach { s ->
                val st = com.kidscreate.studio.draw.Stroke(s.color, s.width, s.eraser)
                st.points.addAll(s.xs.indices.map { androidx.compose.ui.geometry.Offset(s.xs[it], s.ys[it]) })
                f.strokes.add(st)
            }
        }
    }
    Box(
        modifier.aspectRatio(CANVAS_ASPECT).background(Color.White, RoundedCornerShape(10.dp))
            .border(1.dp, Kc.Line, RoundedCornerShape(10.dp)),
    ) {
        androidx.compose.foundation.Canvas(Modifier.fillMaxSize().graphicsLayer(compositingStrategy = CompositingStrategy.Offscreen)) {
            drawFrame(frame)
        }
    }
}

// ---------------- Parent ----------------

@Composable
fun ParentGate(onPass: () -> Unit, onCancel: () -> Unit) {
    val a = remember { (6..9).random() }
    val b = remember { (6..9).random() }
    var answer by remember { mutableStateOf("") }
    var wrong by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onCancel,
        title = { Text("Grown-ups only") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Please answer to continue: what is $a × $b?")
                OutlinedTextField(
                    value = answer, onValueChange = { answer = it.filter(Char::isDigit).take(3); wrong = false },
                    singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                )
                if (wrong) Text("That's not it. Try again.", color = Kc.Draw, fontSize = 13.sp)
            }
        },
        confirmButton = { Button(onClick = { if (answer.toIntOrNull() == a * b) onPass() else wrong = true }) { Text("Continue") } },
        dismissButton = { TextButton(onClick = onCancel) { Text("Cancel") } },
    )
}

@Composable
fun ParentScreen(progress: Progress, lessons: List<Lesson>, onBack: () -> Unit) {
    val context = LocalContext.current
    val cartoons = remember { CartoonStore.list(context).size }
    Column(
        Modifier.verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        ScreenHeader("Parent area", onBack)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Stat("${progress.completed.size} of ${lessons.size}", "Lessons finished", Modifier.weight(1f))
            Stat("${progress.badges.size}", "Badges earned", Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Stat("$cartoons", "Cartoons saved", Modifier.weight(1f))
            Stat(GRADES.first { it.first == progress.grade }.second, "Lesson level", Modifier.weight(1f))
        }
        Card {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Read lessons aloud", Modifier.weight(1f))
                    Switch(checked = progress.readAloud, onCheckedChange = { progress.changeReadAloud(it) })
                }
                Text(
                    "No chat, no ads, no public sharing. Cartoons stay on this device. We keep only a nickname, a buddy and a grade.",
                    fontSize = 12.sp, color = Kc.Muted,
                )
            }
        }
    }
}

@Composable
private fun Stat(value: String, label: String, modifier: Modifier) {
    Column(modifier.background(Kc.Surface, RoundedCornerShape(16.dp)).padding(12.dp)) {
        Text(value, style = MaterialTheme.typography.headlineMedium)
        Text(label, fontSize = 12.sp, color = Kc.Muted)
    }
}

// ---------------- Profile ----------------

@Composable
fun ProfileScreen(progress: Progress, onDone: () -> Unit, onBack: (() -> Unit)?) {
    var name by remember { mutableStateOf(if (progress.hasProfile) progress.name else "") }
    var avatar by remember { mutableIntStateOf(progress.avatar) }
    var grade by remember { mutableStateOf(progress.grade) }
    Column(
        Modifier.verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        ScreenHeader("Who's creating?", onBack)
        OutlinedTextField(
            value = name, onValueChange = { name = it.take(14) }, label = { Text("Your nickname") },
            singleLine = true, modifier = Modifier.fillMaxWidth(),
        )
        Text("Pick your buddy", fontWeight = FontWeight.SemiBold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            AVATAR_COLORS.indices.forEach { i ->
                Box(
                    Modifier.weight(1f).border(if (i == avatar) 3.dp else 0.dp, if (i == avatar) Kc.Ink else Color.Transparent, RoundedCornerShape(18.dp))
                        .padding(3.dp).clickable { avatar = i },
                    contentAlignment = Alignment.Center,
                ) { Avatar(i, 46) }
            }
        }
        Text("Your class", fontWeight = FontWeight.SemiBold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GRADES.forEach { (id, label) ->
                val sel = id == grade
                Text(
                    label,
                    Modifier.weight(1f).background(if (sel) Kc.Ink else Kc.Surface, RoundedCornerShape(14.dp))
                        .border(1.dp, Kc.Line, RoundedCornerShape(14.dp)).clickable { grade = id }.padding(vertical = 12.dp),
                    color = if (sel) Color.White else Kc.Ink, fontWeight = FontWeight.SemiBold, fontSize = 14.sp,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                )
            }
        }
        Text("We only keep a nickname. No real name, email or photos.", color = Kc.Muted, fontSize = 12.sp)
        Button(
            onClick = { progress.saveProfile(name.trim(), avatar, grade); onDone() },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Kc.Ink),
        ) {
            Icon(Icons.Filled.Star, null)
            Text("  Let's create!")
        }
    }
}
