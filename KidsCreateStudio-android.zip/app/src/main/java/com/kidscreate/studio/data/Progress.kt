package com.kidscreate.studio.data

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/**
 * Everything the app remembers about the child. Kept on the device only
 * (SharedPreferences): a nickname, a buddy, a grade band, finished lessons and badges.
 */
class Progress(context: Context) {
    private val prefs = context.getSharedPreferences("progress", Context.MODE_PRIVATE)

    var name by mutableStateOf(prefs.getString("name", "Friend") ?: "Friend")
        private set
    var avatar by mutableStateOf(prefs.getInt("avatar", 0))
        private set
    var grade by mutableStateOf(prefs.getString("grade", "4-5") ?: "4-5")
        private set
    var readAloud by mutableStateOf(prefs.getBoolean("readAloud", true))
        private set
    var hasProfile by mutableStateOf(prefs.contains("name"))
        private set
    var completed by mutableStateOf(prefs.getStringSet("completed", emptySet())!!.toSet())
        private set
    var badges by mutableStateOf(prefs.getStringSet("badges", setOf("starter"))!!.toSet())
        private set

    fun saveProfile(name: String, avatar: Int, grade: String) {
        this.name = name.ifBlank { "Friend" }
        this.avatar = avatar
        this.grade = grade
        hasProfile = true
        prefs.edit().putString("name", this.name).putInt("avatar", avatar).putString("grade", grade).apply()
    }

    fun setReadAloud(on: Boolean) {
        readAloud = on
        prefs.edit().putBoolean("readAloud", on).apply()
    }

    fun complete(lesson: Lesson) {
        completed = completed + lesson.id
        val newBadges = badges.toMutableSet()
        lesson.badge?.let { newBadges += it }
        if (lesson.id == "draw-01-bouncing-ball") newBadges += "first-animation"
        badges = newBadges
        prefs.edit().putStringSet("completed", completed).putStringSet("badges", badges).apply()
    }

    fun addBadge(id: String) {
        if (id in badges) return
        badges = badges + id
        prefs.edit().putStringSet("badges", badges).apply()
    }

    /** A lesson is open when it is the first in its studio or the one before it is finished. */
    fun isUnlocked(lesson: Lesson, all: List<Lesson>): Boolean {
        val sameStudio = all.filter { it.studio == lesson.studio }
        val index = sameStudio.indexOf(lesson)
        if (index <= 0) return true
        if (grade == "9-10") return true
        return sameStudio[index - 1].id in completed
    }
}

data class BadgeInfo(val id: String, val name: String)

val ALL_BADGES = listOf(
    BadgeInfo("starter", "First Steps"),
    BadgeInfo("first-animation", "First Animation"),
    BadgeInfo("bounce-master", "Bounce Master"),
    BadgeInfo("beat-builder", "Beat Builder"),
    BadgeInfo("level-1-animator", "Level 1 Animator"),
)
